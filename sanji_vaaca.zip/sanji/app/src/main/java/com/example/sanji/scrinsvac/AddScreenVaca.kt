package com.example.sanji.scrinsvac

import android.annotation.SuppressLint
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.sanji.modelsvac.vacas
import com.example.sanji.naveVaca.NaveVaca
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun AddScreenVaca(
    navController: NavController,
){
    Scaffold(
        topBar = {
            TopAppBar(){
                Icon(
                    imageVector =Icons.Default.ArrowBack,
                    contentDescription ="Arrow Back",
                    modifier = Modifier
                        .clickable {
                            navController.popBackStack()
                        }
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "vacas")
            }},
        floatingActionButton ={
            FloatingActionButton(
                modifier = Modifier.size(32.dp),
                onClick = { navController.navigate(route = NaveVaca.AppVaca.route)}
            ) {
                Icon(
                    imageVector = Icons.Default.AddCircle,
                    contentDescription ="Agregar",
                    tint = Color.White
                )
            }
        },
        floatingActionButtonPosition = FabPosition.End
    ){
        BodyContentVaca(navController)
    }
}
@Composable
fun BodyContentVaca(
    navController:NavController
){
    var Nombre by remember { mutableStateOf("")}
    var Foto by remember { mutableStateOf("") }
    var Poblacion by remember { mutableStateOf("") }
    var Descripcion by remember { mutableStateOf("")}
    var Pais by remember { mutableStateOf("")}
    var corecto by remember { mutableStateOf(false)}
    var showDialog by remember{ mutableStateOf(false)}
    Box(modifier = Modifier.fillMaxWidth()){
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(all = 16.dp)
        ) {
            TextField(
                modifier = Modifier.fillMaxWidth(),
                value=Nombre,
                onValueChange={Nombre= it},
                label ={ Text("Nombre de la especie: ") }
            )
            Spacer(modifier = Modifier.height(20.dp))
            TextField(
                modifier = Modifier.fillMaxWidth(),
                value=Foto,
                onValueChange={Foto= it},
                label ={ Text("Foto de la especie: ") }
            )
            Spacer(modifier = Modifier.height(20.dp))
            TextField(
                modifier = Modifier.fillMaxWidth(),
                value=Poblacion,
                onValueChange={Poblacion= it},
                label ={ Text("Poblacion: ") }
            )
            Spacer(modifier = Modifier.height(20.dp))
            TextField(
                modifier =Modifier.fillMaxWidth(),
                value=Descripcion,
                onValueChange={Descripcion= it},
                label ={Text("Descripcion: ")}
            )
            Spacer(modifier = Modifier.height(20.dp))
            TextField(
                modifier =Modifier.fillMaxWidth(),
                value=Pais,
                onValueChange={Pais= it},
                label ={Text("Pais de origen: ")}
            )
            Spacer(modifier = Modifier.height(20.dp))
            Button(
                onClick = {
                    if(Nombre==""|| Foto==""|| Poblacion==""|| Descripcion==""|| Pais==""){
                        corecto=true
                    }else {
                        val vaca = vacas(Nombre,Foto,Poblacion.toInt(),Descripcion,Pais)
                        Firebase.firestore.collection("vaca").add(vaca)
                        navController.navigate(route = NaveVaca.AppVaca.route)
                    }
                },
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .padding(vertical = 2.dp)
                    .fillMaxWidth()
            ) {
                Text(text = "añade una vaca")
            }
        }
    }
}
