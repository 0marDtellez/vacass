package com.example.sanji.login

import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.ClickableText
import androidx.compose.material.Button
import androidx.compose.material.CircularProgressIndicator
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.sanji.R
import com.example.sanji.login.models.MainViewModel
import com.example.sanji.naveVaca.NaveVaca

@Composable
fun Login (
    isLoading:Boolean,
    siono: Boolean,
    onLoginClick: () -> Unit,
    MainviewModel: MainViewModel,
    navController: NavController
){
    val logo = painterResource(R.drawable.sena)
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceEvenly
    ) {
        Text(
            stringResource(R.string.Loguin_title),
            style = MaterialTheme.typography.h3,
            fontFamily = FontFamily.Serif
        )
        Image(
            painter =logo,
            contentDescription ="logo",
            modifier = Modifier
                .clip(CircleShape)
                .size(300.dp)
        )
        Text(
            stringResource(R.string.Sub_title),
            style = MaterialTheme.typography.h3,
            fontFamily = FontFamily.Serif
        )
        if (isLoading){
            CircularProgressIndicator(modifier = Modifier.size(45.dp))
        }else{
            Button(onClick = onLoginClick) { Text(stringResource(R.string.Login_cta),fontFamily = FontFamily.Serif) }
            Button(onClick = {navController.navigate(route = NaveVaca.AppVaca.route)}){Text(stringResource(R.string.Login_cta))}
        }
        Legaltext()
    }
}
@Composable
fun Legaltext(){
    val anottatedString= buildAnnotatedString {
        append(stringResource(R.string.Text_legal1))
        append(" ")
        pushStringAnnotation(tag = "URL", annotation = "app://terms", )
        withStyle(
            style = SpanStyle(fontWeight = FontWeight.Bold,
                color = MaterialTheme.colors.secondary
            )
        ){
            append(stringResource(R.string.Text_legal2))
        }
        append("")
        pop()
        append(stringResource(R.string.Text_legal3))
        append("")
        pushStringAnnotation(tag = "URL", annotation = "app://privacy")
        withStyle(
            style = SpanStyle(fontWeight = FontWeight.Bold,
                color = MaterialTheme.colors.secondary
            )
        ){
            append(stringResource(R.string.Text_legal4))
        }
        pop()
    }
    Box(contentAlignment = Alignment.Center){
        ClickableText(
            modifier = Modifier.padding(24.dp),
            text =anottatedString
        ){
                offset -> anottatedString.getStringAnnotations("URL",offset,offset)
            .firstOrNull()?.let {
                    tag -> Log.d("APP","Ha dado click en ${tag.item}")
            }
        }
    }
}
