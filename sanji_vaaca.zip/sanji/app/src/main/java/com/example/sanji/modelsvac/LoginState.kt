package com.example.sanji.modelsvac

import androidx.annotation.StringRes

data class LoginState(
    val nom:String="",
    val ema:String="",
    val num:String="",
    val ima:String="",
    val successLogin:Boolean=true,
    @StringRes val errorMessages:Int?=null
)
