package com.example.sanji.modelsvac

class vacas (
    val nombre: String = "",
    val foto:String="",
    val poblacion: Int = 0,
    val descripcion:String="",
    val pais:String="",
)