package com.example.sanji.scrinsvac

import android.annotation.SuppressLint
import android.os.Handler
import android.os.Looper
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.rememberAsyncImagePainter
import com.example.sanji.modelsvac.VacaViewModel
import com.example.sanji.modelsvac.vacas
import com.example.sanji.naveVaca.NaveVaca

@Composable
fun VacaCard(
    vacas: vacas,
    navController:NavController
){
    Card(
        modifier = Modifier
            .padding(all = 16.dp)
            .fillMaxWidth()
            .clickable { navController.navigate(NaveVaca.InfoVacs.createRoute(
                 vacas.foto, vacas.nombre, vacas.descripcion, vacas.pais
            )) }
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Text(text = "Nombre: ${vacas.nombre} ", color = Color.Gray, fontSize = 16.sp)
            //Text(text = "foto:${vacas.foto}")
            Image(
                painter = rememberAsyncImagePainter(model = "${vacas.foto}"),
                contentDescription= "imagen",
                modifier = Modifier.size(128.dp).align(Alignment.CenterHorizontally)
            )
            Text(text = "poblacion: ${vacas.poblacion} ", color = Color.Gray, fontSize = 12.sp)
            Text(text = "descripcion: ${vacas.descripcion}", color = Color.Gray, fontSize = 12.sp)
            Text(text = "pais: ${vacas.pais} ", color = Color.Gray, fontSize = 12.sp)
        }
    }
}
@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun AppVaca(
    navController:NavController,
    viewModel: VacaViewModel,
    nom: String,
    ema: String,
    ima: String,
    singout:()-> Unit,
    onLoginClick: () -> Unit
){
    Scaffold(
        topBar = {
            Column() {
                Row(
                    modifier = Modifier
                        .background(Color.Gray)
                        .fillMaxWidth()
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Image(
                        painter = rememberAsyncImagePainter(ima),
                        contentDescription = "photo",
                        modifier = Modifier
                            .size(85.dp)
                            .border(3.dp, MaterialTheme.colors.onSecondary, CircleShape)
                            .clip(CircleShape)
                    )
                    Column(
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            style = TextStyle(
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            ),
                            text = nom,
                            fontSize = 25.sp,
                            color = MaterialTheme.colors.onSecondary
                        )
                        Text(
                            text = ema,
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colors.onSecondary
                        )
                    }
                }
                Column(
                    modifier = Modifier
                        .width(157.dp)
                        .background(Color.Black)
                        .clickable {
                            singout()
                            Handler(Looper.getMainLooper()).postDelayed({
                                navController.navigate(NaveVaca.Login.route)
                            }, 2000)
                        },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(text = "cerrar")
                }
                Row(
                    modifier = Modifier
                        .width(160.dp)
                        .background(Color.Black)
                        .size(35.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceEvenly
                ){
                    Button(onClick = { navController.navigate(route = NaveVaca.MapVac.route) }) {Text(text = "Mapa")}
                    Spacer(modifier = Modifier.height(20.dp))
                    Button(onClick = { navController.navigate(route = NaveVaca.AddScreenVaca.route) }) {Text(text = "agregar")}
                }
            } }
    ){
        Box(modifier = Modifier.fillMaxSize()) {
            Column() {
                LazyColumn(
                ){
                    items(viewModel.vacas.value){vaca ->
                            VacaCard(vaca, navController)
                    }
                }
            }
        }
    }
}

