package com.example.sanji.modelsvac

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.firestore.ktx.toObjects
import com.google.firebase.ktx.Firebase

class VacaViewModel: ViewModel() {
    private  val _vacas = mutableStateOf<List<vacas>>(emptyList())
    val vacas: State<List<vacas>>
        get() = _vacas
    private val query = Firebase.firestore.collection("vaca")
    init {
        query.addSnapshotListener { value, _ ->
            if (value !=null){
                _vacas.value = value.toObjects()
            }
        }
    }
}