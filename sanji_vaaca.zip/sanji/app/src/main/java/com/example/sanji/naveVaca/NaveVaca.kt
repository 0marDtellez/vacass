package com.example.sanji.naveVaca

import java.net.URLEncoder
import java.nio.charset.StandardCharsets

sealed class NaveVaca(
    val route:String
) {
    object Vistas : NaveVaca(route = "Vistas")
    object Login : NaveVaca(route = "Login")
    object AppVaca : NaveVaca(route = "AppVaca")
    object AddScreenVaca : NaveVaca(route = "AddScreenVaca")
    object MapVac:NaveVaca(route = "MapVac")
    object InfoVacs : NaveVaca("InfoVacs/{foto}/{nombre}/{descripcion}/{pais}"){
        fun createRoute(foto:String,nombre: String, descripcion: String, pais:String): String {
            fun String.encodeUrl() = URLEncoder.encode(this, StandardCharsets.UTF_8.toString())
            return "InfoVacs/${foto.encodeUrl()}/$nombre/$descripcion/$pais"
        }
    }
}
