package com.example.sanji.naveVaca

import androidx.compose.runtime.*
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.sanji.login.Login
import com.example.sanji.login.models.MainViewModel
import com.example.sanji.scrinsvac.AddScreenVaca
import com.example.sanji.scrinsvac.AppVaca
import com.example.sanji.scrinsvac.InfoVacs
import com.example.sanji.scrinsvac.Vistas
import com.example.sanji.scrinsvac.mapasVac.MapVac

@Composable
fun AppNavVaca(
    isLoading:Boolean,
    siono: Boolean,
    singout:()->Unit,
    onLoginClick: () -> Unit,
    MainviewModel: MainViewModel
){
    val navController= rememberNavController()
    NavHost(
        navController =navController,
        startDestination = NaveVaca.Vistas.route,
    ){
        composable(route= NaveVaca.Vistas.route){ Vistas(navController)}
        composable(route= NaveVaca.Login.route){
            if (siono){
                LaunchedEffect(key1 =Unit){
                    navController.navigate(
                        NaveVaca.AppVaca.route
                    ){
                        popUpTo(NaveVaca.Login.route){
                            inclusive=true
                        }
                    }
                }
            }else{
                Login(
                    isLoading,
                    siono,
                    onLoginClick,
                    MainviewModel,
                    navController
                )
            }
        }
        composable(route= NaveVaca.AppVaca.route){
            AppVaca(
                navController,
                viewModel(),
                nom = MainviewModel.state.value.nom,
                ema = MainviewModel.state.value.ema,
                ima = MainviewModel.state.value.ima,
                singout =singout,
                onLoginClick = onLoginClick
            )
        }
        composable(route= NaveVaca.AddScreenVaca.route){
            AddScreenVaca(navController)
        }
        composable(route=NaveVaca.MapVac.route){
            MapVac(navController)
        }
        composable(NaveVaca.InfoVacs.route, arguments = listOf(
            navArgument("foto") { type = NavType.StringType },
            navArgument("nombre") { type = NavType.StringType },
            navArgument("descripcion") { type = NavType.StringType },
            navArgument("pais"){type = NavType.StringType}
        )) {
            InfoVacs(
                navController = navController,
                foto = it.arguments?.getString("foto") ?: "",
                nombre = it.arguments?.getString("nombre") ?: "",
                descripcion = it.arguments?.getString("descripcion") ?:"",
                pais = it.arguments?.getString("pais") ?:""
            )
        }
    }
}