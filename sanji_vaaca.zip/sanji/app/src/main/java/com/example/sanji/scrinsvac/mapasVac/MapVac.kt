package com.example.sanji.scrinsvac.mapasVac

import android.annotation.SuppressLint
import androidx.compose.foundation.layout.size
import androidx.compose.material.FabPosition
import androidx.compose.material.FloatingActionButton
import androidx.compose.material.Icon
import androidx.compose.material.Scaffold
import androidx.compose.material.TopAppBar
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.sanji.naveVaca.NaveVaca
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.MarkerState
@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun MapVac(
    navController: NavController
){
    Scaffold(
        topBar = {TopAppBar{}},
        floatingActionButton ={
            FloatingActionButton(
                modifier =Modifier.size(32.dp),
                onClick = {navController.navigate(route = NaveVaca.AppVaca.route)}
            ) {
                Icon(
                    imageVector = Icons.Default.AddCircle,
                    contentDescription ="Agregar",
                    tint = Color.White
                )
            } },
        floatingActionButtonPosition = FabPosition.Center
    ) {
        val marqer = LatLng(4.693646, -74.217445)
        GoogleMap(){
            Marker(state= MarkerState (position= marqer))
        }
    }
}


